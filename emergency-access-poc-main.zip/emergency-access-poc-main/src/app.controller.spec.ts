import { Test, TestingModule } from '@nestjs/testing';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ProducerService } from './kafka/service/producer.service';

describe('AppController', () => {
  let appController: AppController;

  beforeEach(async () => {
    const mockProducerService = {
      produce: jest.fn(),
    };

    const app: TestingModule = await Test.createTestingModule({
      controllers: [AppController],
      providers: [
        AppService,
        {
          provide: ProducerService,
          useValue: mockProducerService,
        },
      ],
    }).compile();

    appController = app.get<AppController>(AppController);
  });

  describe('root', () => {
    it('should return "Emergency Access - API"', async () => {
      await expect(appController.getApi()).resolves.toBe(
        'Emergency Access - API',
      );
    });
  });
});
