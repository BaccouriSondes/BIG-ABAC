export interface RangerPolicy {
  id: number;
  guid: string;
  isEnabled: boolean;
  version: number;
  service: string;
  name: string;
  policyType: number;
  policyPriority: number;
  description: string;
  isAuditEnabled: boolean;
  resources: {
    [key: string]: {
      values: string[];
      isExcludes: boolean;
      isRecursive: boolean;
    };
  };
  policyItems: PolicyItem[];
  denyPolicyItems: PolicyItem[];
  allowExceptions: PolicyItem[];
  denyExceptions: PolicyItem[];
  dataMaskPolicyItems: any[]; // You can define a more specific type if needed
  rowFilterPolicyItems: any[]; // You can define a more specific type if needed
  serviceType: string;
  options: Record<string, any>;
  validitySchedules: any[]; // You can define a more specific type if needed
  policyLabels: string[];
  zoneName: string;
  isDenyAllElse: boolean;
}

export interface PolicyItem {
  accesses: Access[];
  users: string[];
  groups: string[];
  roles?: string[];
  conditions: Condition[];
  delegateAdmin: boolean;
}

export interface Access {
  type: string;
  isAllowed: boolean;
}

export interface Condition {
  type: string;
  values: string[];
}

// Helper type for specific resource types
export type ResourceType =
  | 'topic'
  | 'consumergroup'
  | 'transactionalid'
  | 'cluster'
  | 'delegationtoken';
