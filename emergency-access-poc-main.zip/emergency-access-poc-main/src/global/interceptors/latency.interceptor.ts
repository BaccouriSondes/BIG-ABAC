import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
  HttpException,
} from '@nestjs/common';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

@Injectable()
export class LatencyInterceptor implements NestInterceptor {
  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const start = Date.now();
    return next.handle().pipe(
      map((data) => {
        const end = Date.now();
        const latency = end - start;

        if (typeof data === 'object' && data !== null) {
          return { ...data, latency: `${latency}ms` };
        }
        return { data, latency: `${latency}ms` };
      }),
      catchError((error) => {
        const end = Date.now();
        const latency = end - start;

        if (error instanceof HttpException) {
          const errorResponse = error.getResponse();
          let modifiedError: any;

          if (typeof errorResponse === 'object' && errorResponse !== null) {
            modifiedError = { ...errorResponse, latency: `${latency}ms` };
          } else {
            modifiedError = {
              statusCode: error.getStatus(),
              message: errorResponse,
              latency: `${latency}ms`,
            };
          }

          return throwError(
            () => new HttpException(modifiedError, error.getStatus()),
          );
        }

        // For non-HttpExceptions, we'll wrap the error in an object with latency
        return throwError(() => ({
          error: error.message || 'An unexpected error occurred',
          latency: `${latency}ms`,
        }));
      }),
    );
  }
}
