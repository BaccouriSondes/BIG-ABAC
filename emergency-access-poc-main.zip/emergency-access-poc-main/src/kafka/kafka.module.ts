import { Global, Module } from '@nestjs/common';
import { DatabaseModule } from '../database/database.module';
import { ConsumerService } from './service/consumer.service';
import { ProducerService } from './service/producer.service';

@Global()
@Module({
  imports: [DatabaseModule],
  providers: [ProducerService, ConsumerService],
  exports: [ProducerService, ConsumerService],
})
export class KafkaModule {}
