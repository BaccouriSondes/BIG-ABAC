export enum KafkaTopics {
  POLICY_CHANGE = 'PolicyChange',
  BIOMETRIC_DATA = 'BiometricData',
  AMBULANCE_STATUS = 'AmbulanceStatus',
  ENVIRONMENTAL_CONDITIONS = 'EnvironmentalConditions',
  PATIENT_REGISTRATION = 'PatientRegistration',
}
