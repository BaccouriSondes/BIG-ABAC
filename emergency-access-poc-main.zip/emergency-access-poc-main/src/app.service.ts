import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  constructor() {}

  async getApi() {
    return 'Emergency Access - API';
  }
}
