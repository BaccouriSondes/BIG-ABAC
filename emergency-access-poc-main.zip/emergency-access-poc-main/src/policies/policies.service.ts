import { Injectable, OnModuleInit, Logger } from '@nestjs/common';
import { ConsumerService } from '../kafka/service/consumer.service';
import { KafkaTopics } from '../kafka/enum/kafka-topics.enum';
import { ConfigService } from '@nestjs/config';
import { logKafkaMessage } from '../utils/kafka-logger.util';
import { AlertDocument } from '../database/schemas/alert.schema';
import axios, { AxiosError } from 'axios';
import { AlertType } from '../database/enum/alert-type.enum';
import { RangerPolicy } from '../global/types/ranger.types';

@Injectable()
export class PoliciesService implements OnModuleInit {
  private readonly logger = new Logger(PoliciesService.name);
  private rangerApiUrl: string;
  private rangerUsername: string;
  private rangerPassword: string;

  constructor(
    private readonly consumerService: ConsumerService,
    private readonly configService: ConfigService,
  ) {
    this.rangerApiUrl = this.configService.get<string>('RANGER_API_URL');
    this.rangerUsername = this.configService.get<string>('RANGER_USERNAME');
    this.rangerPassword = this.configService.get<string>('RANGER_PASSWORD');
  }

  async onModuleInit() {
    await this.consumePolicyChanges();
  }

  private async consumePolicyChanges() {
    try {
      await this.consumerService.consume({
        topic: { topic: KafkaTopics.POLICY_CHANGE },
        config: { groupId: 'policies-consumer' },
        onMessage: async (message) => {
          logKafkaMessage(this.logger, KafkaTopics.POLICY_CHANGE, message);
          const alert = JSON.parse(message.value.toString()) as AlertDocument;
          await this.updatePolicies(alert);
        },
      });
    } catch (error) {
      this.logger.error(
        `Failed to consume policy changes: ${error.message}`,
        error.stack,
      );
    }
  }

  private async updatePolicies(alert: AlertDocument) {
    this.logger.log(
      `Updating policies based on alert: ${JSON.stringify(alert)}`,
    );
    try {
      if (alert.emergency_detected && !alert.emergency_end_time) {
        await this.grantEmergencyAccess(alert);
      } else if (alert.emergency_end_time) {
        await this.revokeEmergencyAccess(alert);
      }
    } catch (error) {
      this.logger.error(
        `Failed to update policies: ${error.message}`,
        error.stack,
      );
    }
  }

  private async grantEmergencyAccess(alert: AlertDocument) {
    this.logger.log(
      `Granting emergency access for patient: ${alert.patientId}`,
    );
    const policy = {
      service: 'dev_kafka',
      name: `emergency_access_${alert.patientId}_${alert.type_alert}_${alert.assigned_doctor}`,
      policyType: 0,
      policyPriority: 1,
      description: `Emergency access policy for patient ${alert.patientId}`,
      isAuditEnabled: true,
      resources: {
        topic: {
          values: [`patient-${alert.patientId}`],
          isExcludes: false,
          isRecursive: false,
        },
      },
      policyItems: [
        {
          accesses: [
            { type: 'publish', isAllowed: true },
            { type: 'consume', isAllowed: true },
            { type: 'describe', isAllowed: true },
          ],
          users: [alert.assigned_doctor],
          groups: [],
          roles: [],
          conditions: [],
          delegateAdmin: false,
        },
      ],
      denyPolicyItems: [],
      allowExceptions: [],
      denyExceptions: [],
      dataMaskPolicyItems: [],
      rowFilterPolicyItems: [],
      serviceType: 'kafka',
      options: {},
      validitySchedules: [],
      policyLabels: ['emergency_access'],
      zoneName: '',
      isDenyAllElse: false,
      isEnabled: true,
      version: 1,
    };

    try {
      await this.createOrUpdateRangerPolicy(policy);
    } catch (error) {
      this.logger.error(
        `Failed to grant emergency access: ${error.message}`,
        error.stack,
      );
    }
  }

  private async revokeEmergencyAccess(alert: AlertDocument) {
    this.logger.log(
      `Revoking emergency access for patient: ${alert.patientId}`,
    );
    const policyName = `emergency_access_${alert.patientId}_${alert.type_alert}_${alert.assigned_doctor}`;
    try {
      await this.deleteRangerPolicy(policyName);
    } catch (error) {
      this.logger.error(
        `Failed to revoke emergency access: ${error.message}`,
        error.stack,
      );
    }
  }

  private async createOrUpdateRangerPolicy(policy: any) {
    try {
      this.logger.log(
        `Creating/Updating Ranger policy: ${JSON.stringify(policy)}`,
      );
      const response = await axios.post(
        `${this.rangerApiUrl}/service/public/v2/api/policy`,
        policy,
        {
          headers: {
            'Content-Type': 'application/json',
          },
          auth: {
            username: this.rangerUsername,
            password: this.rangerPassword,
          },
        },
      );
      this.logger.log(
        `Successfully created/updated Ranger policy: ${policy.name}`,
      );
      return response.data;
    } catch (error) {
      if (axios.isAxiosError(error)) {
        const axiosError = error as AxiosError;
        this.logger.error(
          `Error creating/updating Ranger policy: ${axiosError.message}`,
          axiosError.stack,
        );
        if (axiosError.response) {
          this.logger.error(
            `Response data: ${JSON.stringify(axiosError.response.data)}`,
          );
        }
      } else {
        this.logger.error(
          `Unexpected error creating/updating Ranger policy: ${error.message}`,
          error.stack,
        );
      }
      throw error;
    }
  }

  private async deleteRangerPolicy(policyName: string) {
    try {
      this.logger.log(`Deleting Ranger policy: ${policyName}`);
      await axios.delete(
        `${this.rangerApiUrl}/service/public/v2/api/policy?policyname=${policyName}&servicename=dev_kafka`,
        {
          auth: {
            username: this.rangerUsername,
            password: this.rangerPassword,
          },
        },
      );
      this.logger.log(`Successfully deleted Ranger policy: ${policyName}`);
    } catch (error) {
      if (axios.isAxiosError(error)) {
        const axiosError = error as AxiosError;
        this.logger.error(
          `Error deleting Ranger policy: ${axiosError.message}`,
          axiosError.stack,
        );
        if (axiosError.response) {
          this.logger.error(
            `Response data: ${JSON.stringify(axiosError.response.data)}`,
          );
        }
      } else {
        this.logger.error(
          `Unexpected error deleting Ranger policy: ${error.message}`,
          error.stack,
        );
      }
      throw error;
    }
  }

  async checkAccess(
    doctorId: string,
    patientId: string,
    alertType: AlertType,
  ): Promise<boolean> {
    this.logger.log(
      `Checking access for doctor ${doctorId} to patient ${patientId} for alert type ${alertType}`,
    );

    try {
      const policies = await this.fetchPolicies();
      const emergencyPolicyName = `emergency_access_${patientId}_${alertType}_${doctorId}`;

      const emergencyPolicy = policies.find(
        (policy) =>
          policy.name === emergencyPolicyName &&
          policy.isEnabled &&
          policy.resources.topic?.values.includes(`patient-${patientId}`) &&
          policy.policyItems.some((item) => item.users.includes(doctorId)),
      );

      if (emergencyPolicy) {
        this.logger.log(
          `Emergency access policy found for doctor ${doctorId} to patient ${patientId}`,
        );
        return true;
      } else {
        this.logger.log(
          `No emergency access policy found for doctor ${doctorId} to patient ${patientId}`,
        );
        return false;
      }
    } catch (error) {
      this.logger.error(`Error checking access: ${error.message}`, error.stack);
      return false;
    }
  }

  private async fetchPolicies(): Promise<RangerPolicy[]> {
    try {
      const response = await axios.get<RangerPolicy[]>(
        `${this.rangerApiUrl}/service/public/v2/api/policy`,
        {
          params: {
            serviceName: 'dev_kafka',
          },
          auth: {
            username: this.rangerUsername,
            password: this.rangerPassword,
          },
        },
      );
      return response.data;
    } catch (error) {
      this.logger.error(
        `Error fetching policies: ${error.message}`,
        error.stack,
      );
      throw error;
    }
  }
}
