import { Module } from '@nestjs/common';
import { ContextHandlerService } from './context-handler.service';

@Module({
  providers: [ContextHandlerService]
})
export class ContextHandlerModule {}
