import { Injectable, OnModuleInit, Logger } from '@nestjs/common';
import { ConsumerService } from '../kafka/service/consumer.service';
import { ProducerService } from '../kafka/service/producer.service';
import { KafkaTopics } from '../kafka/enum/kafka-topics.enum';
import { AlertRepository } from '../database/repositories/alert.repository';
import { PatientRepository } from '../database/repositories/patient.repository';
import { AmbulanceDataRepository } from '../database/repositories/ambulance-data.repository';
import { EnvironmentalConditionsRepository } from '../database/repositories/environmental-conditions.repository';
import { DoctorRepository } from '../database/repositories/doctor.repository';
import { logKafkaMessage } from '../utils/kafka-logger.util';
import { BiometricType } from '../database/schemas/biometric-data.schema';
import { AmbulanceStatus } from '../database/schemas/ambulance-data.schema';
import { Types } from 'mongoose';
import { ConsentType } from '../database/schemas/alert.schema';
import { CreateAlertDto } from '../database/dto/create-alert.dto';
import { AlertType } from '../database/enum/alert-type.enum';
import { DoctorSpecialty } from '../database/enum/doctor-specialty.enum';

@Injectable()
export class ContextHandlerService implements OnModuleInit {
  private readonly logger = new Logger(ContextHandlerService.name);
  private latestData: Map<string, any> = new Map();
  private emergencyStatus: Map<string, boolean> = new Map();

  constructor(
    private readonly consumerService: ConsumerService,
    private readonly producerService: ProducerService,
    private readonly alertRepository: AlertRepository,
    private readonly patientRepository: PatientRepository,
    private readonly ambulanceDataRepository: AmbulanceDataRepository,
    private readonly environmentalConditionsRepository: EnvironmentalConditionsRepository,
    private readonly doctorRepository: DoctorRepository,
  ) {}

  async onModuleInit() {
    await this.consumePatientRegistration();
    await this.consumeBiometricData();
    await this.consumeAmbulanceStatus();
    await this.consumeEnvironmentalConditions();
  }

  private async consumePatientRegistration() {
    await this.consumerService.consume({
      topic: { topic: KafkaTopics.PATIENT_REGISTRATION },
      config: { groupId: 'context-handler-patient-registration' },
      onMessage: async (message) => {
        logKafkaMessage(this.logger, KafkaTopics.PATIENT_REGISTRATION, message);
        const patientData = JSON.parse(message.value.toString());
        this.logger.log(`Patient registered: ${JSON.stringify(patientData)}`);
        this.latestData.set(`patient_${patientData._id}`, patientData);
      },
    });
  }

  private async consumeBiometricData() {
    await this.consumerService.consume({
      topic: { topic: KafkaTopics.BIOMETRIC_DATA },
      config: { groupId: 'context-handler-biometric' },
      onMessage: async (message) => {
        logKafkaMessage(this.logger, KafkaTopics.BIOMETRIC_DATA, message);
        const biometricData = JSON.parse(message.value.toString());
        await this.processBiometricData(biometricData);
      },
    });
  }

  private async consumeAmbulanceStatus() {
    await this.consumerService.consume({
      topic: { topic: KafkaTopics.AMBULANCE_STATUS },
      config: { groupId: 'context-handler-ambulance' },
      onMessage: async (message) => {
        logKafkaMessage(this.logger, KafkaTopics.AMBULANCE_STATUS, message);
        const ambulanceData = JSON.parse(message.value.toString());
        this.logger.log(
          `Ambulance status updated: ${JSON.stringify(ambulanceData)}`,
        );
      },
    });
  }

  private async consumeEnvironmentalConditions() {
    await this.consumerService.consume({
      topic: { topic: KafkaTopics.ENVIRONMENTAL_CONDITIONS },
      config: { groupId: 'context-handler-environmental' },
      onMessage: async (message) => {
        logKafkaMessage(
          this.logger,
          KafkaTopics.ENVIRONMENTAL_CONDITIONS,
          message,
        );
        const environmentalData = JSON.parse(message.value.toString());
        this.logger.log(
          `Environmental conditions updated: ${JSON.stringify(environmentalData)}`,
        );
      },
    });
  }

  private async processBiometricData(data: any) {
    this.logger.log(`Processing biometric data: ${JSON.stringify(data)}`);
    const currentEmergency = this.emergencyStatus.get(data.patientId);
    const newEmergency = this.detectEmergency(data);

    this.latestData.set(`biometric_${data.patientId}`, data);

    if (currentEmergency !== newEmergency) {
      this.emergencyStatus.set(data.patientId, newEmergency);
      this.logger.log(
        `Emergency status changed for patient ${data.patientId}: ${newEmergency}`,
      );
    }

    await this.handleAlert(data.patientId, newEmergency, data);
  }

  private async handleAlert(
    patientId: string,
    emergency: boolean,
    biometricData: any,
  ) {
    this.logger.log(
      `handleAlert: patientId: ${patientId}, emergency: ${emergency}, biometricData: ${JSON.stringify(biometricData)}`,
    );

    const alertType = this.determineAlertType(biometricData);
    const existingAlert = await this.alertRepository.findOne({
      patientId: new Types.ObjectId(patientId),
      type_alert: alertType,
      emergency_end_time: null, // Only consider active alerts
    });

    if (existingAlert) {
      if (emergency) {
        // Update existing alert
        const updateData: any = {
          updatedAt: new Date(),
          last_biometric_data: biometricData,
        };
        const updatedAlert = await this.alertRepository.findOneAndUpdate(
          { _id: existingAlert._id },
          { $set: updateData },
        );
        this.logger.log(
          `Updated existing alert: ${JSON.stringify(updatedAlert)}`,
        );
        await this.producePolicyChange(updatedAlert);
      } else {
        // End the existing alert
        this.logger.log(
          `Ending emergency for patient: ${patientId}, alert: ${existingAlert._id}`,
        );
        const updateData: any = {
          updatedAt: new Date(),
          emergency_detected: false,
          emergency_end_time: new Date(),
        };
        const updatedAlert = await this.alertRepository.findOneAndUpdate(
          { _id: existingAlert._id },
          updateData,
        );
        this.logger.log(
          `Emergency ended. Updated alert: ${JSON.stringify(updatedAlert)}`,
        );
        await this.producePolicyChange(updatedAlert);
        this.logger.log(`Policy change produced for ended emergency`);
      }
    } else if (emergency) {
      // Generate a new alert
      await this.generateAlert(patientId, emergency, biometricData);
    }
  }

  private async generateAlert(
    patientId: string,
    emergency: boolean,
    biometricData: any,
  ) {
    this.logger.log(`Generating alert for patient: ${patientId}`);
    const patientData = await this.getPatientData(patientId);

    if (!patientData) {
      this.logger.warn(
        `Missing patient data for patient ${patientId}. Cannot generate alert.`,
      );
      return;
    }

    const alertType = this.determineAlertType(biometricData);
    const doctorSpecialty = this.determineDoctorSpecialty(alertType);
    const consentType = this.determineConsentType(patientData);

    const assignedDoctor = await this.assignDoctor(doctorSpecialty);

    if (!assignedDoctor) {
      this.logger.warn(
        `No available doctor found for specialty: ${doctorSpecialty}`,
      );
    }

    const alertDto: CreateAlertDto = {
      _id: new Types.ObjectId(),
      patientId: new Types.ObjectId(patientId),
      emergency_detected: emergency,
      type_alert: alertType,
      patient_location: await this.getPatientLocation(patientId),
      consent_type: consentType,
      ambulance_status: await this.getAmbulanceStatus(patientId),
      environmental_conditions:
        await this.getEnvironmentalConditions(patientId),
      doctor_specialty: doctorSpecialty,
      emergency_start_time: new Date(),
      emergency_end_time: null,
      last_biometric_data: biometricData,
      assigned_doctor: assignedDoctor ? assignedDoctor._id : null,
    };

    try {
      const savedAlert = await this.alertRepository.createAlert(alertDto);
      this.logger.log(`Alert stored in MongoDB with ID: ${savedAlert._id}`);

      if (assignedDoctor) {
        await this.patientRepository.addDoctorToPatient(
          new Types.ObjectId(patientId),
          assignedDoctor._id,
        );
        this.logger.log(
          `Doctor ${assignedDoctor._id} assigned to patient ${patientId}`,
        );
      }

      await this.producePolicyChange(savedAlert);
      this.logger.log(`Policy change produced for new alert ${savedAlert._id}`);
    } catch (error) {
      this.logger.error(
        `Failed to generate alert for patient ${patientId}: ${error.message}`,
        error.stack,
      );
    }
  }

  private detectEmergency(data: any): boolean {
    this.logger.log(`Detecting emergency for data: ${JSON.stringify(data)}`);
    switch (data.type) {
      case BiometricType.HEART_RATE:
        return parseInt(data.value) > 120 || parseInt(data.value) < 40;
      case BiometricType.BLOOD_PRESSURE:
        const [systolic, diastolic] = data.value.split('/').map(Number);
        return (
          systolic > 180 || systolic < 90 || diastolic > 120 || diastolic < 60
        );
      case BiometricType.BODY_TEMPERATURE:
        return parseFloat(data.value) > 39 || parseFloat(data.value) < 35;
      case BiometricType.BODY_OXYGEN:
        return parseInt(data.value) < 90;
      default:
        return false;
    }
  }

  private async getPatientData(patientId: string): Promise<any> {
    return await this.patientRepository.findOne({
      _id: new Types.ObjectId(patientId),
    });
  }

  private determineAlertType(data: any): AlertType {
    switch (data.type) {
      case BiometricType.HEART_RATE:
      case BiometricType.BLOOD_PRESSURE:
        return AlertType.CARDIAC;
      case BiometricType.BODY_OXYGEN:
        return AlertType.RESPIRATORY;
      case BiometricType.BODY_TEMPERATURE:
        return AlertType.GENERAL;
      default:
        return AlertType.GENERAL;
    }
  }

  private determineDoctorSpecialty(alertType: AlertType): DoctorSpecialty {
    switch (alertType) {
      case AlertType.CARDIAC:
        return DoctorSpecialty.CARDIOLOGIST;
      case AlertType.RESPIRATORY:
        return DoctorSpecialty.PULMONOLOGIST;
      case AlertType.SURGICAL:
        return DoctorSpecialty.SURGEON;
      case AlertType.ANESTHESIA:
        return DoctorSpecialty.ANESTHETIST;
      case AlertType.TRAUMA:
        return DoctorSpecialty.TRAUMA_NURSE;
      case AlertType.PEDIATRIC:
        return DoctorSpecialty.PEDIATRICIAN;
      case AlertType.NEURO:
        return DoctorSpecialty.NEUROLOGIST;
      case AlertType.INTENSIVE:
        return DoctorSpecialty.INTENSIVIST;
      default:
        return DoctorSpecialty.GENERAL_PRACTITIONER;
    }
  }

  private determineConsentType(patientData: any): ConsentType {
    if (patientData.consent) {
      return ConsentType.PATIENT;
    } else if (patientData.familyAuthorized) {
      return ConsentType.FAMILY;
    } else {
      return ConsentType.NONE;
    }
  }

  private async assignDoctor(specialty: DoctorSpecialty) {
    const doctors = await this.doctorRepository.find({ specialty });

    if (doctors.length === 0) {
      return null;
    }

    // Find the doctor with the least number of assigned patients
    let leastAssignedDoctor = doctors[0];
    let minPatients = Infinity;

    for (const doctor of doctors) {
      const patientCount = await this.patientRepository.countDocuments({
        doctors: doctor._id,
      });

      if (patientCount < minPatients) {
        minPatients = patientCount;
        leastAssignedDoctor = doctor;
      }
    }

    return leastAssignedDoctor;
  }

  private async getPatientLocation(patientId: string): Promise<any> {
    const ambulanceData = await this.ambulanceDataRepository.findOne({
      patientId: new Types.ObjectId(patientId),
    });
    return ambulanceData
      ? ambulanceData.location
      : { latitude: 0, longitude: 0 };
  }

  private async getAmbulanceStatus(patientId: string): Promise<string> {
    const ambulanceData = await this.ambulanceDataRepository.findOne({
      patientId: new Types.ObjectId(patientId),
    });
    return ambulanceData ? ambulanceData.status : AmbulanceStatus.ENROUTE;
  }

  private async getEnvironmentalConditions(patientId: string): Promise<any> {
    const environmentalData =
      await this.environmentalConditionsRepository.findOne({
        patientId: new Types.ObjectId(patientId),
      });
    return environmentalData || { temperature: 25, pollution: 50 };
  }

  private async producePolicyChange(alert: any) {
    try {
      await this.producerService.produce(KafkaTopics.POLICY_CHANGE, {
        value: JSON.stringify(alert),
      });
      this.logger.log(`Policy change produced for alert: ${alert._id}`);
    } catch (error) {
      this.logger.error(
        `Failed to produce policy change: ${error.message}`,
        error.stack,
      );
    }
  }
}
