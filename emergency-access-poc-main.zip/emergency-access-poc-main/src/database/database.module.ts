import { Global, Module } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { DatabaseService } from './database.service';
import { Patient, PatientSchema } from './schemas/patient.schema';
import {
  BiometricData,
  BiometricDataSchema,
} from './schemas/biometric-data.schema';
import {
  AmbulanceData,
  AmbulanceDataSchema,
} from './schemas/ambulance-data.schema';
import {
  EnvironmentalConditions,
  EnvironmentalConditionsSchema,
} from './schemas/environmental-conditions.schema';
import { Alert, AlertSchema } from './schemas/alert.schema';
import { Doctor, DoctorSchema } from './schemas/doctor.schema';
import { AlertRepository } from './repositories/alert.repository';
import { AmbulanceDataRepository } from './repositories/ambulance-data.repository';
import { BiometricDataRepository } from './repositories/biometric-data.repository';
import { EnvironmentalConditionsRepository } from './repositories/environmental-conditions.repository';
import { PatientRepository } from './repositories/patient.repository';
import { DoctorRepository } from './repositories/doctor.repository';
import { DatabaseSeeder } from './database.seeder';

@Global()
@Module({
  imports: [
    MongooseModule.forRootAsync({
      useFactory: (configService: ConfigService) => ({
        uri: configService.get<string>('MONGODB_URI'),
      }),
      inject: [ConfigService],
    }),
    MongooseModule.forFeature([
      { name: Patient.name, schema: PatientSchema },
      { name: BiometricData.name, schema: BiometricDataSchema },
      { name: AmbulanceData.name, schema: AmbulanceDataSchema },
      {
        name: EnvironmentalConditions.name,
        schema: EnvironmentalConditionsSchema,
      },
      { name: Alert.name, schema: AlertSchema },
      { name: Doctor.name, schema: DoctorSchema },
    ]),
  ],
  providers: [
    DatabaseService,
    AlertRepository,
    AmbulanceDataRepository,
    BiometricDataRepository,
    EnvironmentalConditionsRepository,
    PatientRepository,
    DoctorRepository,
    DatabaseSeeder,
  ],
  exports: [
    DatabaseService,
    MongooseModule,
    AlertRepository,
    AmbulanceDataRepository,
    BiometricDataRepository,
    EnvironmentalConditionsRepository,
    PatientRepository,
    DoctorRepository,
    DatabaseSeeder,
  ],
})
export class DatabaseModule {}
