import { Injectable, Logger } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { AbstractRepository } from './abstract.repository';
import { AmbulanceData } from '../schemas/ambulance-data.schema';

@Injectable()
export class AmbulanceDataRepository extends AbstractRepository<AmbulanceData> {
  protected readonly logger = new Logger(AmbulanceDataRepository.name);

  constructor(
    @InjectModel(AmbulanceData.name) ambulanceDataModel: Model<AmbulanceData>,
  ) {
    super(ambulanceDataModel);
  }
}
