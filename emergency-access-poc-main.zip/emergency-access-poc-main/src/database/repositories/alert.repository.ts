import { Injectable, Logger } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { AbstractRepository } from './abstract.repository';
import { Alert, AlertDocument } from '../schemas/alert.schema';
import { CreateAlertDto } from '../dto/create-alert.dto';

@Injectable()
export class AlertRepository extends AbstractRepository<AlertDocument> {
  protected readonly logger = new Logger(AlertRepository.name);

  constructor(@InjectModel(Alert.name) alertModel: Model<AlertDocument>) {
    super(alertModel);
  }

  async createAlert(createAlertDto: CreateAlertDto): Promise<AlertDocument> {
    const alert = new this.model(createAlertDto);
    return alert.save();
  }
}
