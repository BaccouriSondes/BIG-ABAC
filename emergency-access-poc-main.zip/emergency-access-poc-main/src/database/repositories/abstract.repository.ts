import { Logger } from '@nestjs/common';
import { FilterQuery, Model, Types, UpdateQuery } from 'mongoose';
import { AbstractDocument } from '../schemas/abstract.schema';

export abstract class AbstractRepository<TDocument extends AbstractDocument> {
  protected abstract readonly logger: Logger;

  constructor(protected readonly model: Model<TDocument>) {}

  async create(
    document: Omit<TDocument, '_id' | 'createdAt' | 'updatedAt'>,
  ): Promise<TDocument> {
    const createdDocument = new this.model({
      ...document,
      _id: new Types.ObjectId(),
    });
    return (await createdDocument.save()).toJSON() as TDocument;
  }

  async findOne(
    filterQuery: FilterQuery<TDocument>,
  ): Promise<TDocument | null> {
    const document = await this.model.findOne(filterQuery, {}, { lean: true });

    if (!document) {
      this.logger.warn('Document not found with filterQuery', filterQuery);
      return null;
    }

    return document as TDocument;
  }

  async findOneAndUpdate(
    filterQuery: FilterQuery<TDocument>,
    update: UpdateQuery<TDocument>,
  ): Promise<TDocument | null> {
    const document = await this.model.findOneAndUpdate(
      filterQuery,
      { $set: { ...update, updatedAt: new Date() } },
      { new: true, lean: true },
    );

    if (!document) {
      this.logger.warn(`Document not found with filterQuery:`, filterQuery);
      return null;
    }

    return document as TDocument;
  }

  async find(
    filterQuery: FilterQuery<TDocument>,
    limit?: number,
    sort?: Record<string, 1 | -1>,
  ): Promise<TDocument[]> {
    let query = this.model.find(filterQuery, {}, { lean: true });

    if (sort) {
      query = query.sort(sort);
    }

    if (limit) {
      query = query.limit(limit);
    }

    const documents = await query.exec();
    return documents.map((doc) =>
      this.convertToAbstractDocument(doc as TDocument),
    );
  }

  private convertToAbstractDocument(document: Partial<TDocument>): TDocument {
    const abstractDocument = {
      ...document,
      _id: new Types.ObjectId(document._id),
    } as TDocument;

    return abstractDocument;
  }

  async findOneAndDelete(
    filterQuery: FilterQuery<TDocument>,
  ): Promise<TDocument | null> {
    const document = await this.model.findOneAndDelete(filterQuery, {
      lean: true,
    });
    return document as TDocument | null;
  }

  async updateMany(
    filterQuery: FilterQuery<TDocument>,
    update: UpdateQuery<TDocument>,
  ): Promise<{ matchedCount: number; modifiedCount: number }> {
    const result = await this.model.updateMany(filterQuery, {
      ...update,
      $set: { updatedAt: new Date() },
    });
    return {
      matchedCount: result.matchedCount,
      modifiedCount: result.modifiedCount,
    };
  }

  async deleteMany(filterQuery: FilterQuery<TDocument>): Promise<number> {
    const result = await this.model.deleteMany(filterQuery);
    return result.deletedCount;
  }

  async count(filterQuery: FilterQuery<TDocument>): Promise<number> {
    return this.model.countDocuments(filterQuery);
  }
}
