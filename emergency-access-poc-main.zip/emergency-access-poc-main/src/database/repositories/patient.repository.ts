import { Injectable, Logger } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { AbstractRepository } from './abstract.repository';
import { Patient } from '../schemas/patient.schema';

@Injectable()
export class PatientRepository extends AbstractRepository<Patient> {
  protected readonly logger = new Logger(PatientRepository.name);

  constructor(@InjectModel(Patient.name) patientModel: Model<Patient>) {
    super(patientModel);
  }

  async findOneAndUpdate(
    filterQuery: Record<string, any>,
    update: Partial<Patient>,
  ): Promise<Patient> {
    const document = await this.model.findOneAndUpdate(filterQuery, update, {
      new: true,
      runValidators: true,
    });

    if (!document) {
      this.logger.warn(`Patient not found with filterQuery:`, filterQuery);
      return null;
    }

    return document;
  }

  async addDoctorToPatient(
    patientId: Types.ObjectId,
    doctorId: Types.ObjectId,
  ): Promise<Patient> {
    return this.model.findByIdAndUpdate(
      patientId,
      { $addToSet: { doctors: doctorId } } as any,
      { new: true, runValidators: true },
    );
  }

  async countDocuments(filterQuery: Record<string, any>): Promise<number> {
    return this.model.countDocuments(filterQuery);
  }
}
