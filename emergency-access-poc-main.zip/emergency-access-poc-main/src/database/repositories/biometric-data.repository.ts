import { Injectable, Logger } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { AbstractRepository } from './abstract.repository';
import { BiometricData } from '../schemas/biometric-data.schema';

@Injectable()
export class BiometricDataRepository extends AbstractRepository<BiometricData> {
  protected readonly logger = new Logger(BiometricDataRepository.name);

  constructor(
    @InjectModel(BiometricData.name) biometricDataModel: Model<BiometricData>,
  ) {
    super(biometricDataModel);
  }
}
