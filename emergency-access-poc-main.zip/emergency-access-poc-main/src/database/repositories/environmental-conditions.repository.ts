import { Injectable, Logger } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { AbstractRepository } from './abstract.repository';
import { EnvironmentalConditions } from '../schemas/environmental-conditions.schema';

@Injectable()
export class EnvironmentalConditionsRepository extends AbstractRepository<EnvironmentalConditions> {
  protected readonly logger = new Logger(
    EnvironmentalConditionsRepository.name,
  );

  constructor(
    @InjectModel(EnvironmentalConditions.name)
    environmentalConditionsModel: Model<EnvironmentalConditions>,
  ) {
    super(environmentalConditionsModel);
  }
}
