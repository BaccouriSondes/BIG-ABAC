import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Patient } from './schemas/patient.schema';
import { Doctor } from './schemas/doctor.schema';
import { faker } from '@faker-js/faker';
import { DoctorSpecialty } from './enum/doctor-specialty.enum';

@Injectable()
export class DatabaseSeeder {
  constructor(
    @InjectModel(Patient.name) private patientModel: Model<Patient>,
    @InjectModel(Doctor.name) private doctorModel: Model<Doctor>,
  ) {}

  async seed(): Promise<void> {
    await this.seedPatients();
    await this.seedDoctors();
    console.log('Seeding completed successfully');
  }

  private async seedPatients(): Promise<void> {
    const patients = Array(5)
      .fill(null)
      .map(() => ({
        name: faker.person.fullName(),
        age: faker.number.int({ min: 18, max: 100 }),
        familyAuthorized: true,
        consent: true,
      }));

    await this.patientModel.insertMany(patients);
    console.log('Patients seeded successfully');
  }

  private async seedDoctors(): Promise<void> {
    const specialties: DoctorSpecialty[] = [
      DoctorSpecialty.CARDIOLOGIST,
      DoctorSpecialty.PULMONOLOGIST,
      DoctorSpecialty.SURGEON,
      DoctorSpecialty.ANESTHETIST,
      DoctorSpecialty.TRAUMA_NURSE,
      DoctorSpecialty.GENERAL_PRACTITIONER,
      DoctorSpecialty.PEDIATRICIAN,
      DoctorSpecialty.NEUROLOGIST,
      DoctorSpecialty.INTENSIVIST,
    ];

    const doctors = specialties.flatMap((specialty) =>
      Array(2)
        .fill(null)
        .map(() => ({
          name: `Dr. ${faker.person.fullName()}`,
          specialty,
        })),
    );

    await this.doctorModel.insertMany(doctors);
    console.log('Doctors seeded successfully');
  }
}
