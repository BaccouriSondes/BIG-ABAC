export enum DoctorSpecialty {
  CARDIOLOGIST = 'cardiologist',
  PULMONOLOGIST = 'pulmonologist',
  SURGEON = 'surgeon',
  ANESTHETIST = 'anesthetist',
  TRAUMA_NURSE = 'trauma_nurse',
  GENERAL_PRACTITIONER = 'general_practitioner',
  PEDIATRICIAN = 'pediatrician',
  NEUROLOGIST = 'neurologist',
  INTENSIVIST = 'intensivist',
}
