export enum AlertType {
  CARDIAC = 'cardiac',
  RESPIRATORY = 'respiratory',
  SURGICAL = 'surgical',
  ANESTHESIA = 'anesthesia',
  TRAUMA = 'trauma',
  GENERAL = 'general',
  PEDIATRIC = 'pediatric',
  NEURO = 'neuro',
  INTENSIVE = 'intensive',
}
