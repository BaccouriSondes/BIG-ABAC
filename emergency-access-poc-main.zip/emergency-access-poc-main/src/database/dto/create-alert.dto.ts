import { Types } from 'mongoose';
import { ConsentType } from '../schemas/alert.schema';
import { AlertType } from '../enum/alert-type.enum';
import { DoctorSpecialty } from '../enum/doctor-specialty.enum';

export class CreateAlertDto {
  _id: Types.ObjectId;
  patientId: Types.ObjectId;
  emergency_detected: boolean;
  type_alert: AlertType;
  patient_location: {
    latitude: number;
    longitude: number;
  };
  consent_type: ConsentType;
  ambulance_status: string;
  environmental_conditions: {
    temperature: number;
    pollution: number;
  };
  doctor_specialty: DoctorSpecialty;
  emergency_start_time: Date;
  emergency_end_time: Date | null;
  last_biometric_data: any;
  assigned_doctor: Types.ObjectId | null;
}
