import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { AbstractDocument } from './abstract.schema';
import { DoctorSpecialty } from '../enum/doctor-specialty.enum';

@Schema({ versionKey: false })
export class Doctor extends AbstractDocument {
  @Prop({ required: true })
  name: string;

  @Prop({ required: true, enum: DoctorSpecialty })
  specialty: DoctorSpecialty;
}

export const DoctorSchema = SchemaFactory.createForClass(Doctor);
