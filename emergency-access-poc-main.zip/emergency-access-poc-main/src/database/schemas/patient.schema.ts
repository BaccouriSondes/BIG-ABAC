import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { AbstractDocument } from './abstract.schema';
import { Types } from 'mongoose';

@Schema({ versionKey: false })
export class Patient extends AbstractDocument {
  @Prop({ required: true })
  name: string;

  @Prop({ required: true })
  age: number;

  @Prop({ required: true })
  consent: boolean;

  @Prop({ required: true })
  familyAuthorized: boolean;

  @Prop({ type: [{ type: Types.ObjectId, ref: 'Doctor' }] })
  doctors: Types.ObjectId[];
}

export const PatientSchema = SchemaFactory.createForClass(Patient);
