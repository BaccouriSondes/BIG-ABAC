import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Types } from 'mongoose';
import { AbstractDocument } from './abstract.schema';

@Schema({ versionKey: false })
export class EnvironmentalConditions extends AbstractDocument {
  @Prop({ type: Types.ObjectId, ref: 'Patient', required: true })
  patientId: Types.ObjectId;

  @Prop({ required: true })
  temperature: number;

  @Prop({ required: true })
  pollution: number;
}

export const EnvironmentalConditionsSchema = SchemaFactory.createForClass(
  EnvironmentalConditions,
);
