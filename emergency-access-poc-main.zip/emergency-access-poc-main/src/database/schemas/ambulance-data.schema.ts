import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';
import { AbstractDocument } from './abstract.schema';

export enum AmbulanceStatus {
  ENROUTE = 'enroute',
  ON_SITE = 'on site',
}

@Schema({ versionKey: false })
class Location {
  @Prop({ required: true, type: Number })
  latitude: number;

  @Prop({ required: true, type: Number })
  longitude: number;
}

@Schema({ versionKey: false })
export class AmbulanceData extends AbstractDocument {
  @Prop({ type: Types.ObjectId, ref: 'Patient', required: true })
  patientId: Types.ObjectId;

  @Prop({ type: String, enum: AmbulanceStatus, required: true })
  status: AmbulanceStatus;

  @Prop({ type: Location, required: true })
  location: Location;

  @Prop({ type: Number, required: false })
  estimatedTimeOfArrival?: number;
}

export type AmbulanceDataDocument = AmbulanceData & Document;
export const AmbulanceDataSchema = SchemaFactory.createForClass(AmbulanceData);
