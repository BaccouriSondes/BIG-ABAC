import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';
import { AbstractDocument } from './abstract.schema';

export enum BiometricType {
  HEART_RATE = 'heartrate',
  BLOOD_PRESSURE = 'bloodpressure',
  BODY_TEMPERATURE = 'bodytemperature',
  BODY_OXYGEN = 'bodyoxygen',
}

@Schema({ versionKey: false })
export class BiometricData extends AbstractDocument {
  @Prop({ type: Types.ObjectId, ref: 'Patient', required: true })
  patientId: Types.ObjectId;

  @Prop({ type: String, enum: BiometricType, required: true })
  type: BiometricType;

  @Prop({ required: true })
  value: string;
}

export type BiometricDataDocument = BiometricData & Document;
export const BiometricDataSchema = SchemaFactory.createForClass(BiometricData);
