import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';
import { AbstractDocument } from './abstract.schema';
import { AlertType } from '../enum/alert-type.enum';
import { DoctorSpecialty } from '../enum/doctor-specialty.enum';

export enum ConsentType {
  PATIENT = 'patient',
  FAMILY = 'family',
  NONE = 'none',
}

@Schema({ versionKey: false })
export class Alert extends AbstractDocument {
  @Prop({ type: Types.ObjectId, ref: 'Patient', required: true })
  patientId: Types.ObjectId;

  @Prop({ required: true })
  emergency_detected: boolean;

  @Prop({ type: String, enum: AlertType, required: true })
  type_alert: AlertType;

  @Prop({ type: Object, required: true })
  patient_location: {
    latitude: number;
    longitude: number;
  };

  @Prop({ type: String, enum: ConsentType, required: true })
  consent_type: ConsentType;

  @Prop({ required: true })
  ambulance_status: string;

  @Prop({ type: Object, required: true })
  environmental_conditions: {
    temperature: number;
    pollution: number;
  };

  @Prop({ type: String, enum: DoctorSpecialty, required: true })
  doctor_specialty: DoctorSpecialty;

  @Prop({ required: true })
  emergency_start_time: Date;

  @Prop({ type: Date, default: null })
  emergency_end_time: Date | null;

  @Prop({ type: Types.ObjectId, ref: 'Doctor', default: null })
  assigned_doctor: Types.ObjectId | null;

  @Prop({ type: Object, required: true })
  last_biometric_data: Record<string, any>;
}

export type AlertDocument = Alert & Document;
export const AlertSchema = SchemaFactory.createForClass(Alert);
