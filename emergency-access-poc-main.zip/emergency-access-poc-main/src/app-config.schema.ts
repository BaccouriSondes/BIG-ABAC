import * as Joi from 'joi';

export const appConfigSchema = Joi.object({
  APP_ENV: Joi.string().required(),
  PORT: Joi.number().default(8080).required(),
  MONGODB_URI: Joi.string().required(),
  KAFKA_BROKER: Joi.string().required(),
  KAFKA_CLIENT_ID: Joi.string().required(),
  KAFKA_GROUP_ID: Joi.string().required(),
  RANGER_API_URL: Joi.string().required(),
  RANGER_USERNAME: Joi.string().required(),
  RANGER_PASSWORD: Joi.string().required(),
});
