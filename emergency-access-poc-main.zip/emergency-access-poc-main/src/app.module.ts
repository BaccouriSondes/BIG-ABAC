import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { KafkaModule } from './kafka/kafka.module';
import { DatabaseModule } from './database/database.module';
import { appConfigSchema } from './app-config.schema';
import { SimulateModule } from './simulate/simulate.module';
import { ContextHandlerModule } from './context-handler/context-handler.module';
import { PoliciesModule } from './policies/policies.module';
import { CommandsModule } from './commands/commands.module';
import { HealthcareModule } from './healthcare/healthcare.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: [`.env.${process.env.APP_ENV || 'dev'}`],
      validationSchema: appConfigSchema,
    }),
    KafkaModule,
    DatabaseModule,
    SimulateModule,
    ContextHandlerModule,
    PoliciesModule,
    CommandsModule,
    HealthcareModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
