// Helper function to access resources with type safety
import { RangerPolicy, ResourceType } from '../global/types/ranger.types';

export function getResource(policy: RangerPolicy, resourceType: ResourceType) {
  return policy.resources[resourceType];
}
