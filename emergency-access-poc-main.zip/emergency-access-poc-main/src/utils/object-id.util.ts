import { Types } from 'mongoose';

export class ObjectIdUtils {
  /**
   * Checks if the given value is a valid ObjectId.
   * @param id The value to check.
   * @returns True if the value is a valid ObjectId, false otherwise.
   */
  static isValidObjectId(id: any): boolean {
    if (id instanceof Types.ObjectId) {
      return true;
    }
    if (typeof id === 'string') {
      return Types.ObjectId.isValid(id);
    }
    return false;
  }

  /**
   * Filters an array of potential ObjectIds, returning only the valid ones.
   * @param ids An array of potential ObjectIds (can be strings or ObjectId instances).
   * @returns An array of valid ObjectIds.
   */
  static filterValidObjectIds(
    ids: (string | Types.ObjectId)[],
  ): Types.ObjectId[] {
    return ids
      .filter(this.isValidObjectId)
      .map((id) =>
        id instanceof Types.ObjectId ? id : new Types.ObjectId(id),
      );
  }
}
