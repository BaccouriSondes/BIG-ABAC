import { Logger } from '@nestjs/common';
import { KafkaMessage } from 'kafkajs';

export function logKafkaMessage(
  logger: Logger,
  topic: string,
  message: KafkaMessage,
) {
  const logMessage = {
    topic,
    offset: message.offset,
    key: message.key?.toString(),
    value: message.value?.toString(),
    headers: message.headers,
    timestamp: message.timestamp,
  };
  logger.log(`Received Kafka message: ${JSON.stringify(logMessage)}`);
}
