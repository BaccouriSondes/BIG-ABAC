import {
  Controller,
  Get,
  Param,
  UseInterceptors,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiParam,
  ApiBearerAuth,
  ApiUnauthorizedResponse,
  ApiForbiddenResponse,
} from '@nestjs/swagger';
import { HealthcareService } from './healthcare.service';
import { PoliciesService } from '../policies/policies.service';
import { AlertType } from '../database/enum/alert-type.enum';
import { LatencyInterceptor } from '../global/interceptors/latency.interceptor';

@ApiTags('Healthcare')
@ApiBearerAuth()
@Controller('healthcare')
@UseInterceptors(LatencyInterceptor)
export class HealthcareController {
  constructor(
    private readonly healthcareService: HealthcareService,
    private readonly policiesService: PoliciesService,
  ) {}

  @Get('patient/:patientId/doctor/:doctorId/:alertType')
  @ApiOperation({ summary: 'Get patient details' })
  @ApiParam({ name: 'patientId', description: 'ID of the patient' })
  @ApiParam({ name: 'doctorId', description: 'ID of the requesting doctor' })
  @ApiParam({
    name: 'alertType',
    enum: AlertType,
    description: 'Type of alert',
  })
  @ApiResponse({
    status: 200,
    description: 'Returns patient details with latency information.',
    schema: {
      type: 'object',
      properties: {
        // ... other properties ...
        latency: {
          type: 'string',
          example: '123ms',
        },
      },
    },
  })
  @ApiUnauthorizedResponse({
    description: 'Unauthorized',
    schema: {
      type: 'object',
      properties: {
        statusCode: { type: 'number' },
        message: { type: 'string' },
        latency: { type: 'string' },
      },
    },
  })
  @ApiForbiddenResponse({
    description: 'Access denied',
    schema: {
      type: 'object',
      properties: {
        statusCode: { type: 'number' },
        message: { type: 'string' },
        latency: { type: 'string' },
      },
    },
  })
  async getPatientDetails(
    @Param('patientId') patientId: string,
    @Param('doctorId') doctorId: string,
    @Param('alertType') alertType: AlertType,
  ) {
    const hasAccess = await this.policiesService.checkAccess(
      doctorId,
      patientId,
      alertType,
    );

    if (!hasAccess) {
      throw new HttpException(
        {
          statusCode: HttpStatus.FORBIDDEN,
          message: 'Access denied',
        },
        HttpStatus.FORBIDDEN,
      );
    }

    return this.healthcareService.getPatientDetails(patientId);
  }
}
