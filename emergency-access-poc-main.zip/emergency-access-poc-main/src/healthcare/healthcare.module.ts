import { Module } from '@nestjs/common';
import { HealthcareController } from './healthcare.controller';
import { HealthcareService } from './healthcare.service';
import { DatabaseModule } from '../database/database.module';
import { KafkaModule } from '../kafka/kafka.module';
import { PatientRepository } from '../database/repositories/patient.repository';
import { BiometricDataRepository } from '../database/repositories/biometric-data.repository';
import { AmbulanceDataRepository } from '../database/repositories/ambulance-data.repository';
import { EnvironmentalConditionsRepository } from '../database/repositories/environmental-conditions.repository';
import { PoliciesService } from '../policies/policies.service';

@Module({
  imports: [DatabaseModule, KafkaModule],
  controllers: [HealthcareController],
  providers: [
    HealthcareService,
    PoliciesService,
    PatientRepository,
    BiometricDataRepository,
    AmbulanceDataRepository,
    EnvironmentalConditionsRepository,
  ],
})
export class HealthcareModule {}
