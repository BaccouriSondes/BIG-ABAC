import { Injectable, NotFoundException } from '@nestjs/common';
import { Types } from 'mongoose';
import { PatientRepository } from '../database/repositories/patient.repository';
import { BiometricDataRepository } from '../database/repositories/biometric-data.repository';
import { DoctorRepository } from '../database/repositories/doctor.repository';

@Injectable()
export class HealthcareService {
  constructor(
    private readonly patientRepository: PatientRepository,
    private readonly biometricDataRepository: BiometricDataRepository,
    private readonly doctorRepository: DoctorRepository,
  ) {}

  async getPatientDetails(id: string) {
    const patient = await this.patientRepository.findOne({
      _id: new Types.ObjectId(id),
    });
    if (!patient) {
      throw new NotFoundException(`Patient with ID "${id}" not found`);
    }

    const doctors = await this.doctorRepository.find({
      _id: { $in: patient.doctors },
    });
    const biometricData = await this.biometricDataRepository.find({
      patientId: patient._id,
    });

    return {
      ...patient,
      doctors: doctors.map((doctor) => ({
        id: doctor._id,
        name: doctor.name,
        specialty: doctor.specialty,
      })),
      biometricData: biometricData.map((data) => ({
        id: data._id,
        type: data.type,
        value: data.value,
        recordedAt: data.createdAt,
      })),
    };
  }
}
