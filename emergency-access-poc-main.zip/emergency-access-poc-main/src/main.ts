import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { ConfigService } from '@nestjs/config';
import { version } from '../package.json';
import { ValidationPipe, Logger } from '@nestjs/common';
import { CommandFactory } from 'nest-commander';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const config: ConfigService = app.get(ConfigService);

  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
    }),
  );

  app.enableCors();

  const swaggerConfig = new DocumentBuilder()
    .setTitle('Emergency Access - API')
    .setDescription(
      `Emergency Access - API. It is currently using ${config.get(
        'APP_ENV',
      )} environment.`,
    )
    .setVersion(version)
    .addBearerAuth({ type: 'http', scheme: 'bearer', bearerFormat: 'JWT' })
    .build();

  const document = SwaggerModule.createDocument(app, swaggerConfig);
  SwaggerModule.setup('docs', app, document, {
    customSiteTitle: 'Emergency Access - API',
  });

  await app.listen(config.get('PORT'), () =>
    Logger.log(`Server started on port: ${config.get('PORT')}...`, 'main.ts'),
  );
}

async function runCommand() {
  await CommandFactory.run(AppModule);
}

if (require.main === module) {
  const args = process.argv.slice(2);
  if (args.length > 0 && args[0] === 'seed') {
    runCommand();
  } else {
    bootstrap();
  }
}
