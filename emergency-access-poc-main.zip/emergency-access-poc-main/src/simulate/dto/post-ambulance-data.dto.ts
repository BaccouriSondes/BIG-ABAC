// src/dto/post-ambulance-data.dto.ts
import {
  IsEnum,
  IsNumber,
  ValidateNested,
  Min,
  Max,
  IsOptional,
} from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { AmbulanceStatus } from '../../database/schemas/ambulance-data.schema';

class LocationDto {
  @ApiProperty({
    description: 'The latitude coordinate',
    example: 40.7128,
    minimum: -90,
    maximum: 90,
  })
  @IsNumber()
  @Min(-90)
  @Max(90)
  latitude: number;

  @ApiProperty({
    description: 'The longitude coordinate',
    example: -74.006,
    minimum: -180,
    maximum: 180,
  })
  @IsNumber()
  @Min(-180)
  @Max(180)
  longitude: number;
}

export class PostAmbulanceDataDto {
  @ApiProperty({
    enum: AmbulanceStatus,
    description: 'The current status of the ambulance',
    example: AmbulanceStatus.ENROUTE,
  })
  @IsEnum(AmbulanceStatus)
  status: AmbulanceStatus;

  @ApiProperty({ description: 'The current location of the ambulance' })
  @ValidateNested()
  @Type(() => LocationDto)
  location: LocationDto;

  @ApiPropertyOptional({
    description: 'Estimated time of arrival in minutes',
    example: 10,
    minimum: 0,
  })
  @IsNumber()
  @Min(0)
  @IsOptional()
  estimatedTimeOfArrival?: number;
}
