import { PostBiometricDataDto } from './post-biometric-data.dto';
import { PostAmbulanceDataDto } from './post-ambulance-data.dto';
import { PostEnvironmentalConditionsDto } from './post-environmental-conditions.dto';
import { ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

export class PatientConditionsDataDto {
  @ApiProperty({ description: 'Biometric data' })
  @ValidateNested()
  @Type(() => PostBiometricDataDto)
  biometricData: PostBiometricDataDto;

  @ApiProperty({ description: 'Ambulance data' })
  @ValidateNested()
  @Type(() => PostAmbulanceDataDto)
  ambulanceData: PostAmbulanceDataDto;

  @ApiProperty({ description: 'Environmental conditions data' })
  @ValidateNested()
  @Type(() => PostEnvironmentalConditionsDto)
  environmentalData: PostEnvironmentalConditionsDto;
}
