import {
  IsString,
  IsNumber,
  IsBoolean,
  Min,
  Max,
  Length,
  IsOptional,
  IsArray,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Types } from 'mongoose';

export class CreatePatientDto {
  @ApiProperty({ description: 'The name of the patient', example: 'John Doe' })
  @IsString()
  @Length(2, 100)
  name: string;

  @ApiProperty({
    description: 'The age of the patient',
    example: 30,
    minimum: 0,
    maximum: 120,
  })
  @IsNumber()
  @Min(0)
  @Max(120)
  age: number;

  @ApiProperty({
    description: 'Whether the patient has given consent',
    example: true,
  })
  @IsBoolean()
  consent: boolean;

  @ApiProperty({
    description: "Whether the patient's family has authorized treatment",
    example: true,
  })
  @IsBoolean()
  familyAuthorized: boolean;

  @ApiPropertyOptional({
    description: 'Array of doctor IDs associated with the patient',
    type: [String],
  })
  @IsOptional()
  @IsArray()
  doctors?: Types.ObjectId[];
}
