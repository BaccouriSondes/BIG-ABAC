import { IsEnum, IsString, IsNotEmpty } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { BiometricType } from '../../database/schemas/biometric-data.schema';

export class PostBiometricDataDto {
  @ApiProperty({
    enum: BiometricType,
    description: 'The type of biometric data',
    example: BiometricType.HEART_RATE,
  })
  @IsEnum(BiometricType)
  type: BiometricType;

  @ApiProperty({
    description: 'The value of the biometric data',
    example: '75',
  })
  @IsString()
  @IsNotEmpty()
  value: string;
}
