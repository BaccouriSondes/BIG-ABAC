import { IsString, IsNotEmpty, IsEnum } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { DoctorSpecialty } from '../../database/enum/doctor-specialty.enum';

export class CreateDoctorDto {
  @ApiProperty({
    description: 'The name of the doctor',
    example: 'Dr. John Doe',
  })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({
    description: 'The specialty of the doctor',
    enum: DoctorSpecialty,
    example: DoctorSpecialty.CARDIOLOGIST,
  })
  @IsEnum(DoctorSpecialty)
  specialty: DoctorSpecialty;
}
