import { IsNumber, Min, Max } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class PostEnvironmentalConditionsDto {
  @ApiProperty({
    description: 'The ambient temperature in Celsius',
    example: 25,
    minimum: -50,
    maximum: 60,
  })
  @IsNumber()
  @Min(-50)
  @Max(60)
  temperature: number;

  @ApiProperty({
    description: 'The pollution level (e.g., AQI)',
    example: 50,
    minimum: 0,
    maximum: 500,
  })
  @IsNumber()
  @Min(0)
  @Max(500)
  pollution: number;
}
