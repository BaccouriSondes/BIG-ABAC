import { Module } from '@nestjs/common';
import { SimulateController } from './simulate.controller';
import { SimulateService } from './simulate.service';
import { DatabaseModule } from '../database/database.module';
import { KafkaModule } from '../kafka/kafka.module';
import { PatientRepository } from '../database/repositories/patient.repository';
import { BiometricDataRepository } from '../database/repositories/biometric-data.repository';
import { AmbulanceDataRepository } from '../database/repositories/ambulance-data.repository';
import { EnvironmentalConditionsRepository } from '../database/repositories/environmental-conditions.repository';

@Module({
  imports: [DatabaseModule, KafkaModule],
  controllers: [SimulateController],
  providers: [
    SimulateService,
    PatientRepository,
    BiometricDataRepository,
    AmbulanceDataRepository,
    EnvironmentalConditionsRepository,
  ],
})
export class SimulateModule {}
