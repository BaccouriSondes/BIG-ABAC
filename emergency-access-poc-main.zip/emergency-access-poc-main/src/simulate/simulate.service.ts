import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { Types } from 'mongoose';
import { CreatePatientDto } from './dto/create-patient.dto';
import { PostBiometricDataDto } from './dto/post-biometric-data.dto';
import { PostAmbulanceDataDto } from './dto/post-ambulance-data.dto';
import { PostEnvironmentalConditionsDto } from './dto/post-environmental-conditions.dto';
import { validateBiometricData } from './helpers/biometric-data-validator';
import { ProducerService } from '../kafka/service/producer.service';
import { PatientRepository } from '../database/repositories/patient.repository';
import { BiometricDataRepository } from '../database/repositories/biometric-data.repository';
import { AmbulanceDataRepository } from '../database/repositories/ambulance-data.repository';
import { EnvironmentalConditionsRepository } from '../database/repositories/environmental-conditions.repository';
import { KafkaTopics } from '../kafka/enum/kafka-topics.enum';
import { CreateDoctorDto } from './dto/create-doctor.dto';
import { DoctorRepository } from '../database/repositories/doctor.repository';
import { ObjectIdUtils } from '../utils/object-id.util';

@Injectable()
export class SimulateService {
  constructor(
    private readonly patientRepository: PatientRepository,
    private readonly biometricDataRepository: BiometricDataRepository,
    private readonly ambulanceDataRepository: AmbulanceDataRepository,
    private readonly environmentalConditionsRepository: EnvironmentalConditionsRepository,
    private readonly producerService: ProducerService,
    private readonly doctorRepository: DoctorRepository,
  ) {}

  async registerPatient(createPatientDto: CreatePatientDto) {
    let validatedDoctors: Types.ObjectId[] = [];

    if (createPatientDto.doctors && createPatientDto.doctors.length > 0) {
      validatedDoctors = await this.validateDoctorIds(createPatientDto.doctors);
      if (validatedDoctors.length !== createPatientDto.doctors.length) {
        throw new BadRequestException('One or more doctor IDs are invalid');
      }
    }

    const patientData = {
      ...createPatientDto,
      doctors: validatedDoctors,
    };

    const patient = await this.patientRepository.create(patientData);
    await this.producerService.produce(KafkaTopics.PATIENT_REGISTRATION, {
      value: JSON.stringify(patient),
    });
    return patient;
  }

  private async validateDoctorIds(
    doctorIds: (string | Types.ObjectId)[],
  ): Promise<Types.ObjectId[]> {
    const validObjectIds = ObjectIdUtils.filterValidObjectIds(doctorIds);
    const validDoctors = await this.doctorRepository.find({
      _id: { $in: validObjectIds },
    });
    return validDoctors.map((doctor) => doctor._id);
  }

  async postBiometricData(
    patientId: string,
    postBiometricDataDto: PostBiometricDataDto,
  ) {
    const patient = await this.patientRepository.findOne({
      _id: new Types.ObjectId(patientId),
    });
    if (!patient) {
      throw new NotFoundException(`Patient with ID "${patientId}" not found`);
    }

    validateBiometricData(
      postBiometricDataDto.type,
      postBiometricDataDto.value,
    );

    const biometricData = await this.biometricDataRepository.create({
      ...postBiometricDataDto,
      patientId: new Types.ObjectId(patientId),
    });

    await this.producerService.produce(KafkaTopics.BIOMETRIC_DATA, {
      value: JSON.stringify(biometricData),
    });

    return biometricData;
  }

  async postAmbulanceData(
    patientId: string,
    postAmbulanceDataDto: PostAmbulanceDataDto,
  ) {
    const objectId = new Types.ObjectId(patientId);
    const patient = await this.patientRepository.findOne({ _id: objectId });
    if (!patient) {
      throw new NotFoundException(`Patient with ID "${patientId}" not found`);
    }

    const ambulanceData = await this.ambulanceDataRepository.create({
      ...postAmbulanceDataDto,
      patientId: objectId,
    });

    await this.producerService.produce(KafkaTopics.AMBULANCE_STATUS, {
      value: JSON.stringify(ambulanceData),
    });

    return ambulanceData;
  }

  async postEnvironmentalConditions(
    patientId: string,
    postEnvironmentalConditionsDto: PostEnvironmentalConditionsDto,
  ) {
    const patient = await this.patientRepository.findOne({
      _id: new Types.ObjectId(patientId),
    });
    if (!patient) {
      throw new NotFoundException(`Patient with ID "${patientId}" not found`);
    }

    const environmentalConditions =
      await this.environmentalConditionsRepository.create({
        ...postEnvironmentalConditionsDto,
        patientId: new Types.ObjectId(patientId),
      });

    await this.producerService.produce(KafkaTopics.ENVIRONMENTAL_CONDITIONS, {
      value: JSON.stringify(environmentalConditions),
    });

    return environmentalConditions;
  }

  async getAllPatients() {
    return this.patientRepository.find({});
  }

  async getAllDoctors() {
    return this.doctorRepository.find({});
  }

  async getPatientDetails(id: string) {
    const patient = await this.patientRepository.findOne({
      _id: new Types.ObjectId(id),
    });
    if (!patient) {
      throw new NotFoundException(`Patient with ID "${id}" not found`);
    }

    const doctors = await this.doctorRepository.find({
      _id: { $in: patient.doctors },
    });
    const biometricData = await this.biometricDataRepository.find({
      patientId: patient._id,
    });

    return {
      ...patient,
      doctors: doctors.map((doctor) => ({
        id: doctor._id,
        name: doctor.name,
        specialty: doctor.specialty,
      })),
      biometricData: biometricData.map((data) => ({
        id: data._id,
        type: data.type,
        value: data.value,
        recordedAt: data.createdAt,
      })),
    };
  }

  async createDoctor(createDoctorDto: CreateDoctorDto) {
    return this.doctorRepository.create(createDoctorDto);
  }

  async getDoctorDetails(id: string) {
    const doctor = await this.doctorRepository.findOne({
      _id: new Types.ObjectId(id),
    });
    if (!doctor) {
      throw new NotFoundException(`Doctor with ID "${id}" not found`);
    }

    const patients = await this.patientRepository.find({ doctors: doctor._id });

    return {
      ...doctor,
      patients: await Promise.all(
        patients.map(async (patient) => {
          const latestBiometricDataArray =
            await this.biometricDataRepository.find(
              { patientId: patient._id },
              1,
              { createdAt: -1 },
            );

          const latestBiometricData = latestBiometricDataArray[0];

          return {
            id: patient._id,
            name: patient.name,
            age: patient.age,
            latestBiometricData: latestBiometricData
              ? {
                  type: latestBiometricData.type,
                  value: latestBiometricData.value,
                  recordedAt: latestBiometricData.createdAt,
                }
              : null,
          };
        }),
      ),
    };
  }
}
