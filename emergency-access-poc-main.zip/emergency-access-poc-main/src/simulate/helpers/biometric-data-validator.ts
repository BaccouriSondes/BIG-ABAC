import { BadRequestException } from '@nestjs/common';
import { BiometricType } from '../../database/schemas/biometric-data.schema';

export function validateBiometricData(
  type: BiometricType,
  value: string,
): void {
  switch (type) {
    case BiometricType.HEART_RATE:
      if (
        !/^\d+$/.test(value) ||
        parseInt(value) < 0 ||
        parseInt(value) > 300
      ) {
        throw new BadRequestException(
          'Heart rate must be a number between 0 and 300',
        );
      }
      break;
    case BiometricType.BLOOD_PRESSURE:
      if (!/^\d+\/\d+$/.test(value)) {
        throw new BadRequestException(
          'Blood pressure must be in the format "systolic/diastolic"',
        );
      }
      break;
    case BiometricType.BODY_TEMPERATURE:
      if (
        !/^\d+(\.\d+)?$/.test(value) ||
        parseFloat(value) < 30 ||
        parseFloat(value) > 45
      ) {
        throw new BadRequestException(
          'Body temperature must be a number between 30 and 45',
        );
      }
      break;
    case BiometricType.BODY_OXYGEN:
      if (
        !/^\d+$/.test(value) ||
        parseInt(value) < 0 ||
        parseInt(value) > 100
      ) {
        throw new BadRequestException(
          'Body oxygen must be a percentage between 0 and 100',
        );
      }
      break;
    default:
      throw new BadRequestException('Invalid biometric type');
  }
}
