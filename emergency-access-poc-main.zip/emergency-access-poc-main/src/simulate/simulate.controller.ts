import { Controller, Post, Body, Param, Get } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiParam } from '@nestjs/swagger';
import { SimulateService } from './simulate.service';
import { CreatePatientDto } from './dto/create-patient.dto';
import { PostBiometricDataDto } from './dto/post-biometric-data.dto';
import { PostAmbulanceDataDto } from './dto/post-ambulance-data.dto';
import { PostEnvironmentalConditionsDto } from './dto/post-environmental-conditions.dto';
import { CreateDoctorDto } from './dto/create-doctor.dto';
import { PatientConditionsDataDto } from './dto/patient-conditions-data.dto';

@ApiTags('Simulate')
@Controller('simulate')
export class SimulateController {
  constructor(private readonly simulateService: SimulateService) {}

  @Post('register-patient')
  @ApiOperation({ summary: 'Register a new patient' })
  @ApiResponse({
    status: 201,
    description: 'The patient has been successfully created.',
  })
  async registerPatient(@Body() createPatientDto: CreatePatientDto) {
    return this.simulateService.registerPatient(createPatientDto);
  }

  @Get('patients')
  @ApiOperation({ summary: 'Get all patients' })
  @ApiResponse({ status: 200, description: 'Returns all patients.' })
  async getAllPatients() {
    return this.simulateService.getAllPatients();
  }

  @Get('patients/:id')
  @ApiOperation({ summary: 'Get patient details' })
  @ApiParam({ name: 'id', type: String })
  @ApiResponse({ status: 200, description: 'Returns patient details.' })
  async getPatientDetails(@Param('id') id: string) {
    return this.simulateService.getPatientDetails(id);
  }

  @Post('register-doctor')
  @ApiOperation({ summary: 'Create a new doctor' })
  @ApiResponse({
    status: 201,
    description: 'The doctor has been successfully created.',
  })
  async createDoctor(@Body() createDoctorDto: CreateDoctorDto) {
    return this.simulateService.createDoctor(createDoctorDto);
  }

  @Get('doctors')
  @ApiOperation({ summary: 'Get all doctors' })
  @ApiResponse({ status: 200, description: 'Returns all doctors' })
  async getAllDoctors() {
    return this.simulateService.getAllDoctors();
  }

  @Get('doctors/:id')
  @ApiOperation({ summary: 'Get doctor details' })
  @ApiParam({ name: 'id', type: String })
  @ApiResponse({ status: 200, description: 'Returns doctor details.' })
  async getDoctorDetails(@Param('id') id: string) {
    return this.simulateService.getDoctorDetails(id);
  }

  @Post('biometric-data/:patientId')
  @ApiOperation({ summary: 'Post biometric data for a patient' })
  @ApiParam({ name: 'patientId', type: String })
  @ApiResponse({
    status: 201,
    description: 'The biometric data has been successfully recorded.',
  })
  async postBiometricData(
    @Param('patientId') patientId: string,
    @Body() postBiometricDataDto: PostBiometricDataDto,
  ) {
    return this.simulateService.postBiometricData(
      patientId,
      postBiometricDataDto,
    );
  }

  @Post('ambulance-data/:patientId')
  @ApiOperation({ summary: 'Post ambulance data for a patient' })
  @ApiParam({ name: 'patientId', type: String })
  @ApiResponse({
    status: 201,
    description: 'The ambulance data has been successfully recorded.',
  })
  async postAmbulanceData(
    @Param('patientId') patientId: string,
    @Body() postAmbulanceDataDto: PostAmbulanceDataDto,
  ) {
    return this.simulateService.postAmbulanceData(
      patientId,
      postAmbulanceDataDto,
    );
  }

  @Post('environmental-conditions/:patientId')
  @ApiOperation({ summary: 'Post environmental conditions data for a patient' })
  @ApiParam({ name: 'patientId', type: String })
  @ApiResponse({
    status: 201,
    description:
      'The environmental conditions data has been successfully recorded.',
  })
  async postEnvironmentalConditions(
    @Param('patientId') patientId: string,
    @Body() postEnvironmentalConditionsDto: PostEnvironmentalConditionsDto,
  ) {
    return this.simulateService.postEnvironmentalConditions(
      patientId,
      postEnvironmentalConditionsDto,
    );
  }
  @Post('patient-conditions-data/:patientId')
  @ApiOperation({ summary: 'Post combined data for a patient' })
  @ApiParam({ name: 'patientId', type: String })
  @ApiResponse({
    status: 201,
    description: 'Patient condition data has been successfully recorded.',
  })
  async postCombinedData(
    @Param('patientId') patientId: string,
    @Body() patientConditionsDataDto: PatientConditionsDataDto,
  ) {
    await this.simulateService.postBiometricData(
      patientId,
      patientConditionsDataDto.biometricData,
    );
    await this.simulateService.postAmbulanceData(
      patientId,
      patientConditionsDataDto.ambulanceData,
    );
    await this.simulateService.postEnvironmentalConditions(
      patientId,
      patientConditionsDataDto.environmentalData,
    );
    return {
      message: 'Patient condition data has been successfully recorded.',
    };
  }
}
